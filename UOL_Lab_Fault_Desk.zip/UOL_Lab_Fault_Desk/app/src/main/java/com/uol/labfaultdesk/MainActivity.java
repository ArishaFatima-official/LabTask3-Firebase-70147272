package com.uol.labfaultdesk;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private final List<FaultReport> reports = new ArrayList<>();
    private FaultAdapter adapter;
    private ProgressBar progressBar;
    private TextView tvSummary, tvEmpty;
    private DatabaseReference ref;
    private ValueEventListener listener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressBar = findViewById(R.id.progressBar);
        tvSummary = findViewById(R.id.tvSummary);
        tvEmpty = findViewById(R.id.tvEmpty);
        RecyclerView recycler = findViewById(R.id.recyclerFaults);

        ref = FirebaseDatabase.getInstance("https://uol-lab-fault-desk-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference("faults");

        adapter = new FaultAdapter(reports, report -> {
            if ("Fixed".equalsIgnoreCase(report.getStatus())) {
                Toast.makeText(this, "Already fixed", Toast.LENGTH_SHORT).show();
                return;
            }
            // Update only the status field
            ref.child(report.getId()).child("status").setValue("Fixed");
        });
        recycler.setLayoutManager(new LinearLayoutManager(this));
        recycler.setAdapter(adapter);

        findViewById(R.id.fabReport).setOnClickListener(v ->
                startActivity(new Intent(this, ReportFaultActivity.class)));

        listener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                reports.clear();
                int open = 0, fixed = 0;
                for (DataSnapshot child : snapshot.getChildren()) {
                    FaultReport r = child.getValue(FaultReport.class);
                    if (r == null) continue;
                    r.setId(child.getKey());
                    reports.add(r);
                    if ("Fixed".equalsIgnoreCase(r.getStatus())) fixed++; else open++;
                }
                Collections.reverse(reports); // newest first
                adapter.notifyDataSetChanged();

                progressBar.setVisibility(View.GONE);
                tvEmpty.setVisibility(reports.isEmpty() ? View.VISIBLE : View.GONE);
                tvSummary.setText(open + " Open  •  " + fixed + " Fixed");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(MainActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_LONG).show();
            }
        };
        ref.addValueEventListener(listener);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (ref != null && listener != null) ref.removeEventListener(listener);
    }
}
