package com.uol.labfaultdesk;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ReportFaultActivity extends AppCompatActivity {

    private EditText etLabRoom, etPcNumber, etProblem;
    private RadioGroup rgPriority;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_fault);

        etLabRoom = findViewById(R.id.etLabRoom);
        etPcNumber = findViewById(R.id.etPcNumber);
        etProblem = findViewById(R.id.etProblem);
        rgPriority = findViewById(R.id.rgPriority);
        Button btnSubmit = findViewById(R.id.btnSubmit);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        btnSubmit.setOnClickListener(v -> submitReport());
    }

    private void submitReport() {
        String labRoom = etLabRoom.getText().toString().trim();
        String pcNumber = etPcNumber.getText().toString().trim();
        String problem = etProblem.getText().toString().trim();

        if (labRoom.isEmpty()) { etLabRoom.setError("Lab room is required"); etLabRoom.requestFocus(); return; }
        if (pcNumber.isEmpty()) { etPcNumber.setError("PC number is required"); etPcNumber.requestFocus(); return; }
        if (problem.isEmpty()) { etProblem.setError("Describe the problem"); etProblem.requestFocus(); return; }

        String priority = (rgPriority.getCheckedRadioButtonId() == R.id.rbHigh) ? "High" : "Normal";

        DatabaseReference ref = FirebaseDatabase.getInstance("https://uol-lab-fault-desk-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference("faults");
        String key = ref.push().getKey();
        if (key == null) {
            Toast.makeText(this, "Could not create report ID", Toast.LENGTH_SHORT).show();
            return;
        }

        FaultReport report = new FaultReport(key, labRoom, pcNumber, problem, priority, "Open");
        ref.child(key).setValue(report);

        Toast.makeText(this, "Report submitted", Toast.LENGTH_SHORT).show();
        finish();
    }
}
