package com.uol.labfaultdesk;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class FaultAdapter extends RecyclerView.Adapter<FaultAdapter.VH> {

    public interface OnFaultClickListener { void onFaultClick(FaultReport report); }

    private final List<FaultReport> reports;
    private final OnFaultClickListener listener;

    public FaultAdapter(List<FaultReport> reports, OnFaultClickListener listener) {
        this.reports = reports;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_fault, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        FaultReport r = reports.get(position);
        h.tvTitle.setText(r.getLabRoom() + " – " + r.getPcNumber());
        h.tvProblem.setText(r.getProblem());

        boolean high = "High".equalsIgnoreCase(r.getPriority());
        h.tvPriority.setText(high ? "HIGH" : "NORMAL");
        h.tvPriority.setBackgroundResource(high ? R.drawable.bg_chip_high : R.drawable.bg_chip_normal);
        h.tvPriority.setTextColor(ContextCompat.getColor(h.itemView.getContext(), high ? R.color.red : R.color.green_dark));

        boolean fixed = "Fixed".equalsIgnoreCase(r.getStatus());
        h.tvStatus.setText(fixed ? "Fixed" : "Open");
        if (fixed) {
            h.tvStatus.setBackgroundResource(R.drawable.bg_chip_fixed);
            h.tvStatus.setTextColor(ContextCompat.getColor(h.itemView.getContext(), R.color.text_grey));
            h.card.setCardBackgroundColor(ContextCompat.getColor(h.itemView.getContext(), R.color.fixed_card));
            h.tvHint.setText("Resolved");
        } else {
            h.tvStatus.setBackgroundResource(R.drawable.bg_chip_open);
            h.tvStatus.setTextColor(ContextCompat.getColor(h.itemView.getContext(), R.color.amber));
            h.card.setCardBackgroundColor(ContextCompat.getColor(h.itemView.getContext(), R.color.white));
            h.tvHint.setText("Tap to mark as Fixed");
        }

        h.itemView.setOnClickListener(v -> listener.onFaultClick(r));
    }

    @Override
    public int getItemCount() { return reports.size(); }

    static class VH extends RecyclerView.ViewHolder {
        CardView card;
        TextView tvTitle, tvPriority, tvProblem, tvStatus, tvHint;
        VH(@NonNull View v) {
            super(v);
            card = v.findViewById(R.id.cardFault);
            tvTitle = v.findViewById(R.id.tvTitle);
            tvPriority = v.findViewById(R.id.tvPriority);
            tvProblem = v.findViewById(R.id.tvProblem);
            tvStatus = v.findViewById(R.id.tvStatus);
            tvHint = v.findViewById(R.id.tvHint);
        }
    }
}
