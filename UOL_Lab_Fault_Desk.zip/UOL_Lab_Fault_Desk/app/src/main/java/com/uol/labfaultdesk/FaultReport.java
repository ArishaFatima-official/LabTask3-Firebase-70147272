package com.uol.labfaultdesk;

public class FaultReport {
    private String id;
    private String labRoom;
    private String pcNumber;
    private String problem;
    private String priority;
    private String status;

    // Required empty constructor for Firebase
    public FaultReport() { }

    public FaultReport(String id, String labRoom, String pcNumber,
                       String problem, String priority, String status) {
        this.id = id;
        this.labRoom = labRoom;
        this.pcNumber = pcNumber;
        this.problem = problem;
        this.priority = priority;
        this.status = status;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getLabRoom() { return labRoom; }
    public void setLabRoom(String labRoom) { this.labRoom = labRoom; }
    public String getPcNumber() { return pcNumber; }
    public void setPcNumber(String pcNumber) { this.pcNumber = pcNumber; }
    public String getProblem() { return problem; }
    public void setProblem(String problem) { this.problem = problem; }
    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
