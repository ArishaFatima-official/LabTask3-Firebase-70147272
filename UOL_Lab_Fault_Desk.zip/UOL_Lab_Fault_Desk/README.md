# UOL_Lab_Fault_Desk (Lab Task 03 – Firebase + RecyclerView)

## Setup
1. Open this folder in Android Studio (let Gradle sync).
2. Firebase Console → create project → add Android app, package: `com.uol.labfaultdesk`.
3. Download `google-services.json` and place it in `app/`.
4. Build → Realtime Database → Create database → **Test mode**.
5. Run. Reports are stored under the `faults` node.

## Git / submission
- `app/google-services.json` is in `.gitignore` (do NOT push to public GitHub).
- Include it in the ZIP you upload to SLATE.
- Repo name: `LabTask3_Firebase_<SAP ID>`.

## Why addValueEventListener()?
It keeps listening, so any change (new report, edit in Console, status Fixed) updates the board instantly.
addListenerForSingleValueEvent() reads once only and would need a manual refresh.

## Offline behaviour (for your report)
With no internet, setValue() writes to the local cache, the app keeps working, and the report is queued.
When internet returns, Firebase automatically syncs the pending report to the server.
